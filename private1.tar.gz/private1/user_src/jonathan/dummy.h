//This is required to prevent the build process from failing when HYPRE is
//not detected
