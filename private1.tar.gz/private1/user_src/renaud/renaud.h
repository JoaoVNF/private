// This file was generated automatically during the make process
// and it will be remade automatically
#include<renaud/partitioning.h> 
